### Bảng 7.1. Độ chính xác sáu verdict

| Trường hợp | Expected | Actual | Submission ID | Kết quả |
| --- | --- | --- | --- | --- |
| AC | AC | AC | 1014 | PASS |
| WA | WA | WA | 1015 | PASS |
| CE | CE | CE | 1016 | PASS |
| TLE | TLE | TLE | 1017 | PASS |
| MLE | MLE | MLE | 1018 | PASS |
| RTE | RTE | RTE | 1019 | PASS |

### Bảng 7.2. Kết quả thử tải (ms; bài/giây)

| Run ID | POST | HTTP 200 | HTTP lỗi | DB IDs | FINISHED cuối | FAILED | Chưa xong cuối cửa sổ | HTTP p95 | Verdict p95 | Queue p95 | Throughput | Peak đồng thời |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 20261101T114903-load-a78961 | 10 | 10 | 0 | 10 | 10 | 0 | 0 | 194.61 | 1274.42 | 960.29 | 4.40 | 10 |
| 20261101T114912-load-46ce9a | 100 | 100 | 0 | 100 | 100 | 0 | 0 | 207.82 | 11660.22 | 11108.27 | 7.32 | 100 |
| 20261101T114930-load-5973b9 | 1000 | 800 | 200 | 863 | 863 | 0 | 1 | 1095.36 | 121795.89 | 121363.44 | 5.37 | 858 |

### Bảng 7.2b. k6 thực tế (ms)

| Run ID | VU | POST dự kiến | Iterations | POST lỗi | API IDs | DB IDs | FINISHED | FAILED | Chưa xong | POST p95 | Verdict p95 | Peak đồng thời |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 20261101T120337-k6-7613b8 | 5 | 10 | 10 | 0 | 10 | 10 | 10 | 0 | 0 | 212.87 | 1823.21 | 5 |
| 20261101T120342-k6-991d74 | 20 | 100 | 100 | 0 | 100 | 100 | 100 | 0 | 0 | 230.80 | 3445.58 | 20 |
| 20261101T120359-k6-cd1392 | 200 | 1000 | 1000 | 525 | 475 | 506 | 502 | 0 | 4 | 30206.21 | 91305.09 | 231 |

### Bảng 7.3. Mở rộng Worker, trung bình 3 lần đo

| Worker | Throughput TB | Min | Max | HTTP p95 ms | Verdict p95 ms | Queue p95 ms | Worker busy % | Hoàn tất |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | 2.56 | 2.50 | 2.64 | 155.57 | 22138.37 | 21808.74 | 93.88 | 60/60 × 3 |
| 2 | 4.61 | 4.20 | 5.01 | 103.96 | 12464.33 | 12073.64 | 94.31 | 60/60 × 3 |
| 4 | 6.99 | 6.16 | 7.80 | 161.48 | 8371.22 | 7912.66 | 93.45 | 60/60 × 3 |

### Bảng 7.3b. CPU/RAM container, trung bình mẫu Docker stats

| Worker cấu hình | Thành phần | CPU % | RAM MiB |
| --- | --- | --- | --- |
| 1 | backend | 31.66 | 1101.89 |
| 1 | worker | 3.51 | 19.09 |
| 1 | go-judge | 82.24 | 102.16 |
| 2 | backend | 37.34 | 1110.02 |
| 2 | worker | 6.24 | 38.03 |
| 2 | go-judge | 174.54 | 110.23 |
| 4 | backend | 42.53 | 1157.40 |
| 4 | worker | 10.46 | 75.85 |
| 4 | go-judge | 322.97 | 156.03 |

### Bảng 7.2c. Thời gian compile và chạy testcase đo trực tiếp tại Worker

| Run ID | Mẫu compile | Compile TB ms | Chạy test TB ms |
| --- | --- | --- | --- |
| 20261101T114903-load-a78961 | 10 | 369.09 | 55.49 |
| 20261101T114912-load-46ce9a | 100 | 398.98 | 51.06 |
| 20261101T114930-load-5973b9 | 864 | 358.99 | 60.81 |

### Bảng 7.4. Failover

| Tình huống | Mong đợi | Thực tế | Kết quả | Run ID |
| --- | --- | --- | --- | --- |
| Ngắt Worker đang chấm | REQUEUED; giao Worker khác; kết thúc | FINISHED/TLE; 2 lần ASSIGNED; REQUEUED=True | PASS | 20261101T115653-worker-failure-6531d8 |
| Restart Master | Các ID tiếp tục tới trạng thái cuối | FINISHED=7; FAILED=0; chưa xong=3 | FAIL | 20261101T115703-master-restart-090da6 |