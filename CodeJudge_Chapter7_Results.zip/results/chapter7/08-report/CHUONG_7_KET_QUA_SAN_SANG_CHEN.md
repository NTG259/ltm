# CHƯƠNG 7. THIẾT LẬP THỰC NGHIỆM

## 7.1. Môi trường và phương pháp kiểm thử

Thử nghiệm thực hiện trên CodeJudge local tại commit `985580ffb719651ca8c5cfb7aa2bf0330e1c3cc6`. Máy HP Pavilion Laptop 15-eg2xxx có 16 CPU logic, 16 GiB RAM vật lý; Docker Desktop được cấp 16 CPU logic và 7,59 GiB RAM. PostgreSQL 18, Redis 7, go-judge dùng parallelism 4 và giới hạn container 4 GiB. Bài số 1 (A+B) có 4 testcase, giới hạn mỗi testcase 1000 ms và 256 MiB. Mỗi lượt có `run_id` trong comment mã nguồn để đối chiếu API với PostgreSQL. Thời gian HTTP chỉ tính POST; verdict tính từ `created_at` đến `finished_at`; queue tính từ `created_at` hoặc REQUEUED gần nhất đến ASSIGNED. P50/p95 dùng phép nội suy tuyến tính trên từng tập mẫu.

## 7.2. Kịch bản kiểm thử và kết quả

### 7.2.1. Kiểm tra tính chính xác

Sáu chương trình C++17 lần lượt kích hoạt AC, WA, CE, TLE, MLE và RTE qua API. Kết quả đối chiếu với `submissions`, `submission_events` và `submission_test_results` trong PostgreSQL. Lượt đầu phát hiện Worker ánh xạ sai hai trạng thái go-judge có dấu cách; sau khi sửa trực tiếp lỗi phân loại, lượt kiểm tra lại đạt 6/6.

| Trường hợp | Expected | Actual | Submission ID | PASS/FAIL |
| --- | --- | --- | --- | --- |
| AC | AC | AC | 1014 | PASS |
| WA | WA | WA | 1015 | PASS |
| CE | CE | CE | 1016 | PASS |
| TLE | TLE | TLE | 1017 | PASS |
| MLE | MLE | MLE | 1018 | PASS |
| RTE | RTE | RTE | 1019 | PASS |

*Bảng 7.1. Đối chiếu sáu verdict, run `20261101T114850-accuracy-d23417`.*

![Hình 7.1](../06-grafana/Hinh_7_1_Verdict_Accuracy.png)

*Hình 7.1. Kết quả sáu verdict từ CSV thực nghiệm; không phải ảnh Grafana.*

### 7.2.2. Kiểm thử tải đồng thời

Ba mức tải dùng 5 luồng/10 POST, 20 luồng/100 POST và 200 luồng/1000 POST. Mỗi POST dùng cùng mã AC đã xác minh; `run_id` tách riêng từng lượt. Cột DB IDs là số ID duy nhất đối chiếu từ PostgreSQL; HTTP 200 là số phản hồi thành công tới client. Ở mức lớn, có request timeout dù PostgreSQL vẫn ghi một số bài, nên hai cột không được cộng gộp.

| Run ID | POST | HTTP 200 | HTTP lỗi | DB IDs | FINISHED cuối | FAILED | Chưa xong cuối cửa sổ | HTTP p95 ms | Verdict p95 ms | Queue p95 ms | Bài/s | Peak đồng thời |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 20261101T114903-load-a78961 | 10 | 10 | 0 | 10 | 10 | 0 | 0 | 194.61 | 1274.42 | 960.29 | 4.40 | 10 |
| 20261101T114912-load-46ce9a | 100 | 100 | 0 | 100 | 100 | 0 | 0 | 207.82 | 11660.22 | 11108.27 | 7.32 | 100 |
| 20261101T114930-load-5973b9 | 1000 | 800 | 200 | 863 | 863 | 0 | 1 | 1095.36 | 121795.89 | 121363.44 | 5.37 | 858 |

*Bảng 7.2. Kết quả tải. HTTP p95 tính trên POST 200; verdict và queue tính từ các ID trong database.*

| Run ID | VU | POST dự kiến | Iterations | POST lỗi | API IDs | DB IDs | FINISHED | FAILED | Chưa xong | POST p95 ms | Verdict p95 ms | Peak đồng thời |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 20261101T120337-k6-7613b8 | 5 | 10 | 10 | 0 | 10 | 10 | 10 | 0 | 0 | 212.87 | 1823.21 | 5 |
| 20261101T120342-k6-991d74 | 20 | 100 | 100 | 0 | 100 | 100 | 100 | 0 | 0 | 230.80 | 3445.58 | 20 |
| 20261101T120359-k6-cd1392 | 200 | 1000 | 1000 | 525 | 475 | 506 | 502 | 0 | 4 | 30206.21 | 91305.09 | 231 |

*Bảng 7.2b. Kết quả k6 thực tế; `http_reqs` gồm cả GET polling nên không dùng làm số POST.*

Ở lượt k6 200 VU, 506 ID được ghi trong PostgreSQL; đỉnh đồng thời 231; 4 bài chưa hoàn tất cuối cửa sổ. Số VU là số client ảo, không đồng nghĩa số submission đồng thời.

| Run ID | Mẫu compile | Compile TB ms | Chạy test TB ms |
| --- | --- | --- | --- |
| 20261101T114903-load-a78961 | 10 | 369.09 | 55.49 |
| 20261101T114912-load-46ce9a | 100 | 398.98 | 51.06 |
| 20261101T114930-load-5973b9 | 864 | 358.99 | 60.81 |

*Bảng 7.2c. Thời gian đo trực tiếp quanh `_compile()` và vòng testcase tại Worker; số mẫu có thể lớn hơn số bài nếu có chấm lại.*

![Hình 7.2](../06-grafana/Hinh_7_2_Load_Test_Overview.png)

*Hình 7.2. Số POST thành công và ID ghi nhận trong database, biểu đồ từ CSV thực nghiệm.*

![Hình 7.3](../06-grafana/Hinh_7_3_Response_Time_Throughput.png)

*Hình 7.3. HTTP p95, verdict p95 và throughput theo mức tải, biểu đồ từ CSV thực nghiệm.*

![Hình 7.3b](../06-grafana/Hinh_7_3b_Throughput_Over_Time.png)

*Hình 7.3b. Throughput theo thời gian và số bài đang hoạt động/hàng đợi từ Prometheus, run `20261101T120359-k6-cd1392`.*

![Hình 7.3c](../06-grafana/Grafana_Dashboard_K6_Large.png)

*Hình 7.3c. Ảnh chụp dashboard Grafana thật trong khoảng thời gian k6 200 VU/1000 iterations.*



Mức 1000 POST ghi nhận 800 HTTP 200, 200 lỗi/timeout phía client, 863 ID trong PostgreSQL, đỉnh 858 submission đồng thời. Có 1 bài chưa xong cuối cửa sổ quan sát; bài này hoàn tất sau restart Master. Vì đỉnh thấp hơn 1000, chưa đạt mục tiêu 1000 submission đồng thời.

### 7.2.3. Đánh giá mở rộng Worker

Với mỗi cấu hình 1, 2, 4 Worker, thực hiện 3 lượt độc lập gồm 20 luồng và 60 submission/lượt. Chỉ bắt đầu lượt mới khi không còn bài đang xử lý; số Worker đã đăng ký được kiểm tra trước mỗi lượt. Bảng trình bày trung bình của ba lượt; min-max biểu thị biến thiên throughput.

| Worker | Bài/s TB | Min | Max | HTTP p95 ms | Verdict p95 ms | Queue p95 ms | Busy % TB | Hoàn tất |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | 2.56 | 2.50 | 2.64 | 155.57 | 22138.37 | 21808.74 | 93.88 | 60/60 × 3 |
| 2 | 4.61 | 4.20 | 5.01 | 103.96 | 12464.33 | 12073.64 | 94.31 | 60/60 × 3 |
| 4 | 6.99 | 6.16 | 7.80 | 161.48 | 8371.22 | 7912.66 | 93.45 | 60/60 × 3 |

*Bảng 7.3. So sánh 1/2/4 Worker trên cùng bài và mức tải; độ trễ tính bằng ms.*

| Worker cấu hình | Thành phần | CPU % TB | RAM MiB TB |
| --- | --- | --- | --- |
| 1 | backend | 31.66 | 1101.89 |
| 1 | worker | 3.51 | 19.09 |
| 1 | go-judge | 82.24 | 102.16 |
| 2 | backend | 37.34 | 1110.02 |
| 2 | worker | 6.24 | 38.03 |
| 2 | go-judge | 174.54 | 110.23 |
| 4 | backend | 42.53 | 1157.40 |
| 4 | worker | 10.46 | 75.85 |
| 4 | go-judge | 322.97 | 156.03 |

*Bảng 7.3b. CPU/RAM trung bình theo các mẫu Docker stats; CPU của nhóm Worker là tổng các container Worker.*

![Hình 7.4](../06-grafana/Hinh_7_4_Worker_Scaling.png)

*Hình 7.4. Trung bình và min-max của ba lượt mỗi cấu hình, biểu đồ từ CSV thực nghiệm.*

![Hình 7.5](../06-grafana/Hinh_7_5_Worker_Utilization.png)

*Hình 7.5. Thời gian BUSY/online và mẫu CPU/RAM Worker từ Docker stats; biểu đồ từ CSV thực nghiệm.*

Throughput trung bình 2 Worker bằng 1.80 lần và 4 Worker bằng 2.73 lần mức 1 Worker. Queue p95 giảm 44.6% khi tăng từ 1 lên 2 Worker và giảm thêm 34.5% khi tăng từ 2 lên 4 Worker. Tăng tốc không hoàn toàn tuyến tính. CPU trung bình của go-judge tăng từ 82,24% lên 174,54% và 322,97% qua ba cấu hình; đây là dấu hiệu go-judge dùng chung có thể giới hạn hiệu quả tăng thêm, chưa phải bằng chứng xác định duy nhất điểm nghẽn. Cấu hình 4 Worker cho throughput tuyệt đối cao nhất; 2 Worker dùng ít tài nguyên hơn và đạt khoảng 2.31 bài/giây mỗi Worker, so với 1.75 ở cấu hình 4. Chưa có dữ liệu giá tiền phần cứng để kết luận chi phí tài chính.

### 7.2.4. Kiểm thử khả năng chịu lỗi

Worker failure được gây ra sau khi có sự kiện ASSIGNED của một bài chạy dài. Master restart được thực hiện khi có bài trong hàng đợi và bài đã ASSIGNED. Các ID và lịch sử sự kiện được giữ trước, sau sự cố.

| Tình huống | Mong đợi | Thực tế | PASS/FAIL | Run ID |
| --- | --- | --- | --- | --- |
| Ngắt Worker đang chấm | REQUEUED; giao Worker khác; kết thúc | FINISHED/TLE; 2 lần ASSIGNED; REQUEUED=True | PASS | 20261101T115653-worker-failure-6531d8 |
| Restart Master | Các ID tiếp tục tới trạng thái cuối | FINISHED=7; FAILED=0; chưa xong=3 | FAIL | 20261101T115703-master-restart-090da6 |

*Bảng 7.4. Kết quả hai phép thử failover trên môi trường local.*

![Hình 7.6](../06-grafana/Hinh_7_6_Failover_Recovery.png)

*Hình 7.6. Trục thời gian sự kiện failover lấy từ PostgreSQL; biểu đồ từ CSV thực nghiệm.*

Worker failure có sự kiện REQUEUED sau 1295 ms kể từ ASSIGNED đầu, được giao lại sau 13 ms và kết thúc sau tổng 5920 ms. Đây là thời gian từ sự kiện giao bài, không phải thời gian phát hiện heartbeat vì TCP đã ngắt trực tiếp. Trường attempt trong hai sự kiện đều là 1 và `submissions.attempts` cuối cùng là 0; vì vậy chưa xác nhận được số lần giao đúng theo trường attempt hay tính duy nhất của attemptToken. Với Master restart, 3 bài còn TESTING sau 180 giây; cả ba chỉ hoàn tất TLE sau một lần restart bổ sung. Kết quả trong Bảng 7.4 vẫn là FAIL cho cửa sổ thử ban đầu.

## 7.3. Đánh giá và thảo luận kết quả

Hệ thống phân loại đúng sáu verdict sau khi sửa lỗi ánh xạ TLE/MLE. Tăng Worker cải thiện throughput và giảm chờ hàng đợi trong bộ tải 60 bài, nhưng hiệu quả tăng thêm từ 2 lên 4 Worker thấp hơn tỉ lệ tăng số Worker. Lượt 1000 POST phát theo 200 luồng bộc lộ lỗi HTTP và một bài kẹt hàng đợi tới lúc Master restart, do đó chưa thể xác nhận khả năng phục vụ 1000 submission đồng thời. Phép thử k6 có cách phát tải khác: mỗi VU chờ verdict trước iteration tiếp theo. Các kết luận chỉ áp dụng cho cấu hình local, bài A+B bốn testcase và cửa sổ quan sát đã ghi trong từng `config.json`.
