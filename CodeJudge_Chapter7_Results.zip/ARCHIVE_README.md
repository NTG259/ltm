# CodeJudge Chapter 7 results archive

This archive contains all 19 local experiment runs, including four runs that did not meet their test criteria. `results/chapter7/08-report/` has the completed Chapter 7 report and audit. `07-tables/manifest.json` maps every summary table and chart to source files. `ARCHIVE_MANIFEST.json` contains the SHA-256 and byte count for every packaged file except the manifest itself.

Per-run `config.json`, `summary.json`, CSV and logs are under `02-accuracy/`, `03-load/`, `04-worker-scaling/` and `05-failover/`. The three actual k6 runs each retain their original `k6.csv` and `k6_summary.json`. Their executed JavaScript is under `tests/k6/`, with the Python runner and metric calculation scripts under `tests/`. `monitoring/` has the dashboard and exporter configuration. The DB password default was removed from archived code; provide credentials through environment variables if rerunning against a local DB.

Metric definitions and the local run procedure are in `tests/CHAPTER7.md` and the Chapter 7 report. HTTP POST latency, verdict latency, queue waiting, Worker BUSY/online time and DB-recorded submission counts are separate measures. The 1,000-concurrent-submission target was not met. DOCX render previews were excluded because they are derived from the final DOCX.

No live database, JWT, password value, credential file, `.git` or `node_modules` is included.
